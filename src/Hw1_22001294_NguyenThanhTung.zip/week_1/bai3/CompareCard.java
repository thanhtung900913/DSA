package week_1.bai3;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

class CompareCard implements Comparator<Card> {
    private static final String[] RANK_ORDER = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};

    @Override
    public int compare(Card c1, Card c2) {
        int rank1 = getRankIndex(c1.getRank());
        int rank2 = getRankIndex(c2.getRank());
        return Integer.compare(rank1, rank2);
    }

    private int getRankIndex(String rank) {
        for (int i = 0; i < RANK_ORDER.length; i++) {
            if (RANK_ORDER[i].equals(rank)) {
                return i;
            }
        }
        return -1;
    }
    // Hàm thực hiện sắp xếp nhanh (QuickSort)
    public static void quickSort(Card[] arr, int low, int high) {
        if (low < high) {
            int pi = partition(arr, low, high);
            quickSort(arr, low, pi - 1);
            quickSort(arr, pi + 1, high);
        }
    }

    private static int partition(Card[] arr, int low, int high) {
        Card pivot = arr[high];
        int i = (low - 1);

        for (int j = low; j < high; j++) {
            if (arr[j].compareTo(pivot) < 0) {
                i++;
                Card temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        Card temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;

        return i + 1;
    }

    // Hàm thực hiện sắp xếp trộn (MergeSort)
    public static void mergeSort(Card[] arr, int left, int right) {
        if (left < right) {
            int mid = left + (right - left) / 2;
            mergeSort(arr, left, mid);
            mergeSort(arr, mid + 1, right);
            merge(arr, left, mid, right);
        }
    }

    private static void merge(Card[] arr, int left, int mid, int right) {
        int n1 = mid - left + 1;
        int n2 = right - mid;

        Card[] L = Arrays.copyOfRange(arr, left, mid + 1);
        Card[] R = Arrays.copyOfRange(arr, mid + 1, right + 1);

        int i = 0, j = 0;
        int k = left;

        while (i < n1 && j < n2) {
            if (L[i].compareTo(R[j]) <= 0) {
                arr[k] = L[i];
                i++;
            } else {
                arr[k] = R[j];
                j++;
            }
            k++;
        }

        while (i < n1) {
            arr[k] = L[i];
            i++;
            k++;
        }

        while (j < n2) {
            arr[k] = R[j];
            j++;
            k++;
        }
    }

    public static void main(String[] args) {
        List<Card> deck = Deck.createDeck();
        Card[] deckArray = deck.toArray(new Card[0]);

        // Sắp xếp bằng QuickSort
        quickSort(deckArray, 0, deckArray.length - 1);
        System.out.println("QuickSort:");
        for (Card card : deckArray) {
            System.out.println(card);
        }

        // Sắp xếp bằng MergeSort
        mergeSort(deckArray, 0, deckArray.length - 1);
        System.out.println("MergeSort:");
        for (Card card : deckArray) {
            System.out.println(card);
        }
    }
}
