package week_5.bt1;

public interface Entry <K, E> {
    K getKey();
    E getValue();
}
