package week_5.bt3;

public class Sort {
	public void printArr(int [] input) {
		 for(int a=0; a< input.length; a++) {
	        	System.out.print(input[a]+ " ");
	        }
	}
}
